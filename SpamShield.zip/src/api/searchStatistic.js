// src/api/searchStatistic.js
import request from '@/utils/request'

export function fetchSearchStatistic() {
  return request({
    url: '/mock/search_statistic',
    method: 'get'
  })
}