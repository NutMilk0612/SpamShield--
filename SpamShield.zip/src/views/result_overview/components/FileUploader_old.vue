<template>
    <uploader :options="options" class="uploader-example">
      <uploader-unsupport></uploader-unsupport>
      <uploader-drop>
        <p class="upload-text">上传需要检测的文件</p>
        <uploader-btn>选择.pcap文件</uploader-btn>
        <uploader-btn :attrs="attrs">选择.eml文件</uploader-btn>
        <uploader-btn :directory="true">打开目录</uploader-btn>
      </uploader-drop>
      <uploader-list></uploader-list>
    </uploader>
  </template>
  
  <script>
    export default {
      data () {
        return {
          options: {
            // 可通过 https://github.com/simple-uploader/Uploader/tree/develop/samples/Node.js 示例启动服务
            target: '//localhost:3000/upload',
            testChunks: true
          },
          attrs: {
            accept: 'image/*'
          }
        }
      }
    }
  </script>
  
  <style>
    .uploader-example {
      width: 100%;
      padding: 15px;
      margin: -15px auto 0;
      font-size: 12px;
      box-shadow: 0 0 10px rgba(0, 0, 0, .4);
    }
    .uploader-example .uploader-btn {
      margin-right: 4px;
    }
    .uploader-example .uploader-list {
      max-height: 440px;
      overflow: auto;
      overflow-x: hidden;
      overflow-y: auto;
    }
    .upload-text {
    color: #304156; /* 侧栏同款 */
    font-family: 'Arial', sans-serif; /* Arial字体 */
    font-weight: bold; /* 加粗 */
    font-size: 14px; /* 字体大小 */
  }
  </style>