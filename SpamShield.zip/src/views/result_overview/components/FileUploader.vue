<template>
    <div>
      <!-- :limit="1" 限制上传数量  :drag="true" 可实现拖拽上传 :file-list会返显在下方-->
      <el-upload
        class="upload-demo"
        action="#"
        :drag="true"
        :before-upload="uploadFileFun"
        :file-list="uploadFile.fileList">
        <div class="el-upload__text">将需要检测的.eml文件或.pcap文件拖到此处，或<em>点击上传</em></div>
        <el-button type="primary" @click="startDetection">开始检测</el-button>
    </el-upload>
      <!-- <el-button type="primary" @click="startDetection">开始检测</el-button> -->
      <div v-if="uploadedFileName" class="file-info">
        <span>{{ uploadedFileName }}</span>
        <!-- <el-button type="primary" @click="startDetection">开始检测</el-button> -->
      </div>
    </div>
  </template>
  
  <script>
    export default {
  data () {
    return {
      fileIdArr: [],
      uploadFile: {
        createUser:'',
        createTime:'',
        fileId: '', // 存放选择的文件
        fileList: [],
      },
      uploadFileRules: {
        fileList: [{ required: true, message: "请上传文件", trigger: "blur" }],
      },
      uploadedFileName: '', // 新增：存储上传的文件名
    }
  },
  methods: {
    uploadFileFun(file){
      var test = /(doc|docx|jpg)$/.test(file.type);
      // if (!test) {
      //     this.$message.error("请上传正确的文档格式!");
      //     return false;
      // }
      // const isLt2M = file.size / 1024 / 1024 < 2;
      // if (!isLt2M) {
      //     this.$message.error("上传文件大小不能超过 2MB!");
      //     return false;
      // }
      // 创建formdata实例
      let formData = new window.FormData();
      // 将获取的文件通过append方法加入实例中
      formData.append("file", file);
      this.$api.uploadFile(formData)
        .then(res => {
          // fileList用于反显
          this.uploadFile.fileList.push(res.data)
          this.fileIdArr.push(res.data.id)
          this.uploadedFileName = file.name; // 更新：存储上传的文件名
        })
        .catch(err => {});
    },
    startDetection() {
      // 刷新页面
      location.reload();
    }
  }
}
  </script>
  
  <style>
  .uploader-example {
    width: 100%;
    padding: 15px;
    margin: -15px auto 0;
    font-size: 12px;
    box-shadow: 0 0 10px rgba(0, 0, 0, .4);
  }
  .uploader-example .uploader-btn {
    margin-right: 4px;
  }
  .uploader-example .uploader-list {
    max-height: 440px;
    overflow: auto;
    overflow-x: hidden;
    overflow-y: auto;
  }
  .upload-text {
    color: #304156; /* 侧栏同款 */
    font-family: 'Arial', sans-serif; /* Arial字体 */
    font-weight: bold; /* 加粗 */
    font-size: 17px; /* 字体大小 */
    line-height: 2; /* 设置行间距，可以根据需要调整 */
  }
  .el-upload-dragger {
    background-color: #fff;
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    width: 1070px;
    height: 80px;
    /* display: flex; */
    text-align: center;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .el-upload-dragger .el-upload__text {
    color: #606266;
    font-size: 16px;
    text-align: center;
    line-height: 2; /* 设置行间距，可以根据需要调整 */
    font-weight: bold; /* 加粗 */
  }
  .file-info {
    margin-top: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .el-button--primary {
    color: #606266;
    background-color: #cac1cc;
    border-color: #cac1cc;
    font-weight: bold; /* 加粗 */
}
  </style>