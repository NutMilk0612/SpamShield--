<template>
  <div class="dashboard-editor-container">
    <!-- <github-corner class="github-corner" /> -->
 
    <!-- 文件上传 -->
    <el-row :gutter="32">
      <el-col :xs="24" :sm="24" :lg="24">
          <div class="chart-wrapper">

            <file-uploader />
            <div height="20px"></div>
          </div>
        </el-col>
    </el-row>

      <!-- 总数统计 -->
      <panel-group @handleSetLineChartData="handleSetLineChartData" />

    <!-- 雷达图和花瓣图 -->
    <el-row :gutter="32">
      <el-col :xs="24" :sm="24" :lg="12">
        <div class="chart-wrapper">
          <raddar-chart />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="12">
        <div class="chart-wrapper">
          <pie-chart />
        </div>
      </el-col>
    </el-row>

  </div>
</template>

<script>
// 设置
import GithubCorner from '@/components/GithubCorner'
import PanelGroup from './components/PanelGroup'
// 三个图
import RaddarChart from './components/RaddarChart'
import PieChart from './components/PieChart'
import FileUploader from './components/FileUploader'


export default {
  name: 'DashboardAdmin',
  components: {
    GithubCorner,
    PanelGroup,
    RaddarChart,
    PieChart,
    FileUploader,
  },
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}

@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
