<template>
  <div class="search-statistic">
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="id" label="ID" width="50"></el-table-column>
      <el-table-column prop="subject" label="邮件主题"></el-table-column>
      <el-table-column prop="from" label="来源" width="150"></el-table-column>
      <el-table-column prop="to" label="收件人" width="150"></el-table-column>
      <!-- <el-table-column prop="content" label="Content"></el-table-column> -->
      <el-table-column prop="rules_adapted" label="检测规则">
        <template slot-scope="scope">
          <ul>
            <li v-for="(rule, index) in scope.row.rules_adapted" :key="index">{{ rule }}</li>
          </ul>
        </template>
      </el-table-column>
      <el-table-column prop="related_info" label="相关信息">
        <template slot-scope="scope">
          <ul>
            <li v-for="(info, index) in scope.row.related_info" :key="index">
              IP: {{ info.ip }}
            </li>
          </ul>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { fetchSearchStatistic } from '@/api/searchStatistic'

export default {
  name: 'SearchStatistic',
  data() {
    return {
      tableData: []
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    async fetchData() {
      try {
        const response = await fetchSearchStatistic()
        console.log(response.code )
        if (response.code === 20000) {
          this.tableData = response.data
        }
      } catch (error) {
        console.error('Failed to fetch data:', error)
      }
    }
  }
}
</script>

<style scoped>
.search-statistic {
  padding: 20px;
}
</style>