<template>
  <div class="search-statistic">
    <el-table :data="tableData" style="width: 100%; padding-top: 15px;">
      <!-- <el-table-column
        label="ID"
        width="50"
        :index="indexMethod(0)">
      </el-table-column> -->
      <el-table-column prop="ip" label="欺诈邮件IP" width="170"></el-table-column>
      <!-- <el-table-column prop="domain_name" label="欺诈邮件域名" width="200"></el-table-column> -->
      
      <!-- <el-table-column prop="location" label="定位" width="200">
        <template slot-scope="scope">
          {{ scope.row.lacation.join(', ') }}
        </template>
      </el-table-column> -->
      <el-table-column prop="AS" label="自治系统" width="150"></el-table-column>
      <el-table-column prop="whois.org" label="域名归属组织信息" width="280"></el-table-column>
      
      <el-table-column prop="whois.emails" label="域名归属组织邮件地址" width="250">
      
        <!-- <template slot-scope="scope">
          <ul>
            <li v-for="(email, index) in scope.row.whois.emails" :key="index">{{ email }}</li>
          </ul>
        </template> -->
      </el-table-column>
      
      <!-- <el-table-column prop="whois.state" label="State" width="150"></el-table-column> -->
      <el-table-column prop="whois.country" label="国家" width="120"></el-table-column>
      <!-- <el-table-column prop="whois.city" label="City" width="150"></el-table-column> -->
      <el-table-column prop="whois.registrar" label="域名注册机构" width="200"></el-table-column>
      <!-- <el-table-column prop="tls.subject_org" label="TLS Subject Org" width="200"></el-table-column>
      <el-table-column prop="tls.subject_cn" label="TLS Subject CN" width="200"></el-table-column>
      <el-table-column prop="tls.issuer_org" label="TLS Issuer Org" width="200"></el-table-column>
      <el-table-column prop="tls.issuer_cn" label="TLS Issuer CN" width="200"></el-table-column> -->
    </el-table>
  </div>
</template>

<script>
import { fetchSearchStatistic } from '@/api/searchStatistic'

export default {
  data() {
    return {
      tableData: []
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    async fetchData() {
      try {
        const response = await fetchSearchStatistic()
        if (response.code === 20000) {
          // 提取 related_info 部分
          const relatedInfoData = response.data.flatMap(item => item.related_info)
          console.log(relatedInfoData)
          this.tableData = relatedInfoData
        } else {
          console.error('Unexpected response code:', response.data.code)
        }
      } catch (error) {
        console.error('Failed to fetch data:', error)
      }
    },
    indexMethod(index) {
      return index + 1;
    }
  }
}
</script>

<style scoped>
.search-statistic {
  padding: 20px;
}
</style>