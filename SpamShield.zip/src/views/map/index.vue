<template>
    <div class="world-map-container" ref="worldMapContainer"></div>
  </template>
  
  <script>
  import echarts from 'echarts'
  import 'echarts/map/js/world.js' // 确保引入了世界地图
  
  export default {
    name: 'WorldMap',
    data() {
      return {
        chart: null,
      };
    },
    mounted() {
      this.initMap();
    },
    methods: {
      initMap() {
        // 基于准备好的容器初始化 echarts 实例
        this.chart = echarts.init(this.$refs.worldMapContainer);
  
        // 指定图表的配置项和数据
        const option = {
          title: {
            text: '欺诈邮件地图数据可视化',
            left: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: function (params) {
              if (params.seriesType == 'scatter') {
                return params.name + ' : ' + params.value[2];
              } else {
                return params.name;
              }
            }
          },
          geo: {
            map: 'world',
            roam: true,
            label: {
              emphasis: {
                show: false
              }
            },
            itemStyle: {
              normal: {
                areaColor: '#ffffff',
                borderColor: '#000000'
              },
              emphasis: {
                areaColor: '#32CD32' // 鼠标悬停时的背景颜色改为绿色
              }
            }
          },
          series: [
            {
              name: '标点',
              type: 'scatter',
              coordinateSystem: 'geo',
              symbolSize: 10,
              data: [
                // 示例数据
                {name: 'Beijing', value: [116.407395, 39.904211, 100]},
                {name: 'New York', value: [-74.005973, 40.712776, 120]},
                {name: 'London', value: [-0.127758, 51.507351, 140]},
                // ...根据你的数据动态生成
              ],
              itemStyle: {
                emphasis: {
                  borderColor: '#fff',
                  borderWidth: 2
                }
              }
            }
          ]
        };
  
        // 使用刚指定的配置项和数据显示图表。
        this.chart.setOption(option);
      }
    }
  };
  </script>
  
  <style scoped>
  .world-map-container {
    width: 100%;
    height: 700px;
  }
  </style>
  