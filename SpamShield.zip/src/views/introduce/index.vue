<template>
    <div class="image-container">
      <el-row :gutter="32">
        <img src="@/assets/liucheng.png" alt="Image 1" class="image" />
      </el-row>
      <el-row :gutter="32">
        <img src="@/assets/kuangjia.png" alt="Image 2" class="image" />
      </el-row>
    </div>
  </template>

  
  <script>
    export default {
  name: 'introduce',
  data() {
    return {};
  },
  mounted() {
    // 如果有其他需要在mounted钩子中执行的代码，请在这里添加
  },
  methods: {
    // 如果有其他方法，请在这里添加
  }
};
 
</script>

<style scoped>
.image-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
  width: 100%;
  max-width: 650px;
  margin: 0 auto; /* 使容器在页面中居中 */
}

.image {
  width: 100%;
  max-width: 100%;
  height: auto;
  border: 1.5px solid #000000b7;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px; /* 图片之间的间距 */
}
</style>
