<template>
  <el-table :data="list" style="width: 100%;padding-top: 15px;">
    <el-table-column label="序号" width="50">
      <template slot-scope="scope">
        {{ scope.row.order_no}}
      </template>
    </el-table-column>
    <el-table-column label="时间" min-width="155" align="center">
      <template slot-scope="scope">
        {{ formatDate(scope.row.timestamp) }}
      </template>
    </el-table-column>
    <el-table-column label="源IP地址" min-width="175" align="center">
      <template slot-scope="scope">
        {{ scope.row.price }}
      </template>
    </el-table-column>
    <el-table-column label="检测结果" width="100" align="center">
      <template slot-scope="{row}">
        <el-tag :type="row.status | statusFilter">
          {{ row.status }}
        </el-tag>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import { transactionList } from '@/api/remote-search'

export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        normol: 'success',
        fraud: 'danger'
      }
      return statusMap[status]
    },
    orderNoFilter(str) {
      return str.substring(0, 30)
    }
  },
  data() {
    return {
      list: null
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    fetchData() {
      transactionList().then(response => {
        this.list = response.data.items.slice(0, 7)
      })
    },
    // 数据转为年月日
    formatDate(timestamp) {
      const date = new Date(timestamp);
      const year = date.getFullYear();
      const month = ('0' + (date.getMonth() + 1)).slice(-2);
      const day = ('0' + date.getDate()).slice(-2);
      return `${year}-${month}-${day}`;
    }
  }
}
</script>
