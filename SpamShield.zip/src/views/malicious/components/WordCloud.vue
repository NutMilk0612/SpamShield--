<template>
    <div class="hello">
      <div id="app">
        <wordcloud
        :data="defaultWords"
        nameKey="name"
        valueKey="value"
        :color="myColors"
        :showTooltip="false"
        :wordClick="wordClickHandler">
        </wordcloud>
      </div>
    </div>
  </template>
  <script>
  import wordcloud from 'vue-wordcloud'
  export default {
    name: 'app',
    components: {
      wordcloud
    },
    methods: {
      wordClickHandler(name, value, vm) {
        console.log('wordClickHandler', name, value, vm);
      }
    },
    data() {
      return {
        myColors: ['#36a3f7', '#40c9c6', '#1f77b4', '#f4516c'],
        defaultWords: [        
        {
            "name": "财务部通知",
            "value": 4
        },
        {
            "name": "（补贴））",
            "value": 8
        },
        {
            "name": "安全警告",
            "value": 4
        },
        {
            "name": "及 时 申 领",
            "value": 4
        },
        {
            "name": "退税申报",
            "value": 4
        },
        {
            "name": "申报保留",
            "value": 4
        },
        {
            "name": "备案保持账户",
            "value": 4
        },
        {
            "name": "查看下图查收",
            "value": 4
        },
        {
            "name": "请查看附件及时查收",
            "value": 2
        },
        {
            "name": "用户名和密码",
            "value": 4
        },
        {
            "name": "备案升级",
            "value": 4
        },
        {
            "name": "补〉贴",
            "value": 8
        },
        {
            "name": "（补贴）通知",
            "value": 4
        },
        {
            "name": "版本较低",
            "value": 4
        },
        {
            "name": "IMAP属于同步协议",
            "value": 7
        },
        {
            "name": "当天未完成视为放弃申领！",
            "value": 4
        },
        {
            "name": "请查收！",
            "value": 2
        },
        {
            "name": "日通告",
            "value": 5
        },
        {
            "name": "邮箱系统在线升级",
            "value": 8
        },
        {
            "name": "高温补贴已经下发",
            "value": 4
        },
        {
            "name": "邮件系统通知：",
            "value": 4
        },
        {
            "name": "登录新邮件系统",
            "value": 4
        },
        {
            "name": "财 政",
            "value": 4
        },
        {
            "name": "更优质的电子邮件系统服务",
            "value": 4
        },
        {
            "name": "进一步提升邮件系统的性能和安全",
            "value": 4
        },
        {
            "name": "被善意地关闭",
            "value": 6
        },
        {
            "name": "即将达到容量上限",
            "value": 4
        },
        {
            "name": "财政通知",
            "value": 4
        },
        {
            "name": "高温补助",
            "value": 4
        },
        {
            "name": "高温津贴",
            "value": 4
        },
        {
            "name": "申请登记",
            "value": 4
        },
        {
            "name": "邮件管理专员",
            "value": 4
        },
        {
            "name": "工资补贴",
            "value": 4
        },
        {
            "name": "邮箱储存已满",
            "value": 4
        },
        {
            "name": "附件查看",
            "value": 4
        },
        {
            "name": "原有数据备案",
            "value": 4
        },
        {
            "name": "存储扩容升级",
            "value": 4
        },
        {
            "name": "劳动补贴",
            "value": 4
        },
        {
            "name": "赎回",
            "value": 3
        },
        {
            "name": "点击登录",
            "value": 3
        },
        {
            "name": "迫切希望与您开展业务",
            "value": 4
        },
        {
            "name": "点击登陆",
            "value": 2
        },
        {
            "name": "点此登录",
            "value": 2
        },
        {
            "name": "登陆",
            "value": 2
        },
        {
            "name": "注册",
            "value": 2
        },
        {
            "name": "log in",
            "value": 2
        },
        {
            "name": "sign up",
            "value": 2
        },
        {
            "name": "urgent",
            "value": 2
        },
        {
            "name": "立即申请",
            "value": 2
        },
        {
            "name": "暂停收发信权限",
            "value": 4
        },
        {
            "name": "关闭SMTP解除限制",
            "value": 7
        },
        {
            "name": "务必",
            "value": 4
        },
        {
            "name": "个税汇算清缴",
            "value": 3
        },
        {
            "name": "个税汇算退税",
            "value": 3
        },
        {
            "name": "津贴发放",
            "value": 3
        },
        {
            "name": "项目申报",
            "value": 3
        },]
      }
    }
  }
  </script>