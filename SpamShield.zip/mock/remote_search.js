const Mock = require('mockjs')

const NameList = []
const count = 100

for (let i = 0; i < count; i++) {
  NameList.push(Mock.mock({
    name: '@first'
  }))
}
NameList.push({ name: 'mock-Pan' })

module.exports = [
  // username search
  {
    url: '/vue-element-admin/search/user',
    type: 'get',
    response: config => {
      const { name } = config.query
      const mockNameList = NameList.filter(item => {
        const lowerCaseName = item.name.toLowerCase()
        return !(name && lowerCaseName.indexOf(name.toLowerCase()) < 0)
      })
      return {
        code: 20000,
        data: { items: mockNameList }
      }
    }
  },

  // transaction list
  // {
  //   url: '/vue-element-admin/transaction/list',
  //   type: 'get',
  //   response: _ => {
  //     return {
  //       code: 20000,
  //       data: {
  //         total: 20,
  //         'items|20': [{
  //           order_no: '@guid()',
  //           timestamp: +Mock.Random.date('T'),
  //           username: '@name()',
  //           price: '@float(1000, 15000, 0, 2)',
  //           'status|1': ['fraud', 'normal','unknown']
  //         }]
  //       }
  //     }
  //   }
  // }

  // {
  //   url: '/vue-element-admin/transaction/list',
  //   type: 'get',
  //   response: _ => {
  //     const items = [];
  //     for (let i = 1; i <= 20; i++) {
  //       items.push({
  //         order_no: i,
  //         timestamp: +Mock.Random.date('T'),
  //         username: '@name()',
  //         price: Mock.Random.ip(),
  //         status: Mock.Random.pick(['fraud', 'normal','unknown'])
  //       });
  //     }
  //     return {
  //       code: 20000,
  //       data: {
  //         total: 20,
  //         items: items
  //       }
  //     };
  //   }
  // }
  {
    url: '/vue-element-admin/transaction/list',
    type: 'get',
    response: _ => {
      const items = [];
      for (let i = 1; i <= 20; i++) {
        const date = Mock.Random.date('yyyy-MM-dd');
        const timestamp = new Date(date);
        timestamp.setFullYear(2023); // 将年份设置为2023
  
        items.push({
          order_no: i,
          timestamp: +timestamp,
          username: '@name()',
          price: Mock.Random.ip(),
          status: Mock.Random.pick(['fraud', 'normal', 'unknown'])
        });
      }
      return {
        code: 20000,
        data: {
          total: 20,
          items: items
        }
      };
    }
  }
  
]
